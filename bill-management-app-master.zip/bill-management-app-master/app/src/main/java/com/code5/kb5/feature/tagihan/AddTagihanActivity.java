package com.code5.kb5.feature.tagihan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.code5.kb5.R;

public class AddTagihanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_tagihan);
    }
}
